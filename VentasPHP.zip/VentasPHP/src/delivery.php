<?php
include_once "includes/header.php";
require_once "../conexion.php";
$id_user = $_SESSION['idUser'];
$permiso = "configuracion";
$sql = mysqli_query($conexion, "SELECT p.*, d.* FROM permisos p INNER JOIN detalle_permisos d ON p.id = d.id_permiso WHERE d.id_usuario = $id_user AND p.nombre = '$permiso'");
$existe = mysqli_fetch_all($sql);
if (empty($existe) && $id_user != 1) {
    header("Location: permisos.php");
}

function add_delivery($destinatario, $estado_de_pago, $estado_del_envio, $fecha_de_envio, $tipo_de_servicio, $fecha_de_entrega, $observaciones, $creada_por) {
  global $conn;
  $sql = "INSERT INTO delivery (destinatario, estado_de_pago, estado_del_envio, fecha_de_envio, tipo_de_servicio, fecha_de_entrega, observaciones, creada_por) VALUES ('$destinatario', '$estado_de_pago', '$estado_del_envio', '$fecha_de_envio', '$tipo_de_servicio', '$fecha_de_entrega', '$observaciones', '$creada_por')";
  if ($conn->query($sql) === TRUE) {
    echo "Registro agregado exitosamente";
  } else {
    echo "Error al agregar el registro: " . $conn->error;
  }
}

// Función para obtener todos los registros de la tabla "delivery"
function get_all_delivery() {
  global $conn;
  $sql = "SELECT * FROM delivery";
  $result = $conn->query($sql);
  if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
      echo "ID: " . $row["id"] . " - Destinatario: " . $row["destinatario"] . " - Estado de Pago: " . $row["estado_de_pago"] . " - Estado del Envío: " . $row["estado_del_envio"] . " - Fecha de Envío: " . $row["fecha_de_envio"] . " - Tipo de Servicio: " . $row["tipo_de_servicio"] . " - Fecha de Entrega: " . $row["fecha_de_entrega"] . " - Observaciones: " . $row["observaciones"] . " - Creada por: " . $row["creada_por"] . "<br>";
    }
  } else {
    echo "No se encontraron registros";
}
}

// Función para obtener un registro específico de la tabla "delivery" por ID
function get_delivery_by_id($id) {
global $conn;
$sql = "SELECT * FROM delivery WHERE id=$id";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  $row = $result->fetch_assoc();
  echo "ID: " . $row["id"] . " - Destinatario: " . $row["destinatario"] . " - Estado de Pago: " . $row["estado_de_pago"] . " - Estado del Envío: " . $row["estado_del_envio"] . " - Fecha de Envío: " . $row["fecha_de_envio"] . " - Tipo de Servicio: " . $row["tipo_de_servicio"] . " - Fecha de Entrega: " . $row["fecha_de_entrega"] . " - Observaciones: " . $row["observaciones"] . " - Creada por: " . $row["creada_por"] . "<br>";
} else {
  echo "No se encontró el registro";
}
}

// Función para actualizar un registro específico de la tabla "delivery" por ID
function update_delivery($id, $destinatario, $estado_de_pago, $estado_del_envio, $fecha_de_envio, $tipo_de_servicio, $fecha_de_entrega, $observaciones, $creada_por) {
global $conn;
$sql = "UPDATE delivery SET destinatario='$destinatario', estado_de_pago='$estado_de_pago', estado_del_envio='$estado_del_envio', fecha_de_envio='$fecha_de_envio', tipo_de_servicio='$tipo_de_servicio', fecha_de_entrega='$fecha_de_entrega', observaciones='$observaciones', creada_por='$creada_por' WHERE id=$id";
if ($conn->query($sql) === TRUE) {
  echo "Registro actualizado exitosamente";
} else {
  echo "Error al actualizar el registro: " . $conn->error;
}
}

// Función para eliminar un registro específico de la tabla "delivery" por ID
function delete_delivery($id) {
global $conn;
$sql = "DELETE FROM delivery WHERE id=$id";
if ($conn->query($sql) === TRUE) {
  echo "Registro eliminado exitosamente";
} else {
  echo "Error al eliminar el registro: " . $conn->error;
}
}

// Ejemplo de uso de las funciones CRUD

// Agregar un nuevo registro
add_delivery("Juan Perez", "Pagado", "Enviado", "2023-04-01", "Express", NULL, "Entregar en recepción", "Admin");

// Obtener todos los registros
get_all_delivery();

// Obtener un registro por ID
get_delivery_by_id(1);

// Actualizar un registro por ID
update_delivery(1, "Pedro Gomez", "Pendiente de pago", "En tránsito", "2023-04-02", "Normal", NULL, "Entregar en puerta trasera", "Admin");

// Eliminar un registro por ID
delete_delivery(2);
?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
  <style>
    table {
      border-collapse: collapse;
      width: 100%;
    }

    th, td {
      text-align: left;
      padding: 8px;
    }

    th {
      background-color: #ddd;
    }

    tr:nth-child(even) {
      background-color: #f2f2f2;
    }

    .add-form {
      display: none;
      margin-bottom: 20px;
    }

    .add-form label {
      display: inline-block;
      width: 150px;
      margin-right: 10px;
    }

    .add-form input, .add-form select {
      width: 300px;
      padding: 5px;
      margin-bottom: 10px;
    }

    .add-form button {
      padding: 10px;
      background-color: #4CAF50;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }

    .edit-form {
      display: none;
      margin-bottom: 20px;
    }

    .edit-form label {
      display: inline-block;
      width: 150px;
      margin-right: 10px;
    }

    .edit-form input, .edit-form select {
      width: 300px;
      padding: 5px;
      margin-bottom: 10px;
    }

    .edit-form button {
      padding: 10px;
      background-color: #4CAF50;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }
  </style>
</head>
<body>
  <h1>Delivery Tracker</h1>

  <table>
    <thead>
      <tr>
        <th>ID</th>
        <th>Destinatario</th>
        <th>Estado de Pago</th>
        <th>Estado del Envío</th>
        <th>Fecha de Envío</th>
        <th>Tipo de Servicio</th>
        <th>Fecha de Entrega</th>
        <th>Observaciones</th>
        <th>Creada por</th>
        <th></th>
        <th></th>
      </tr>
    </thead>
    <tbody id="delivery-list">
      <!-- Aquí se insertarán los registros de la tabla "delivery" -->
    </tbody>
  </table>

  <button id="add-btn"><i class="fas fa-plus"></i> Agregar nuevo registro</button>

  <form id="add-form" class="add-form">
    <label for="destinatario">Destinatario:</label>
    <input type="text" id="destinatario" name="destinatario" required><br>

    <label for="estado_de_pago">Estado de Pago:</label>
    <select id="estado_de_pago" name="estado_de_pago">
      <option value="Pendiente">Pendiente</option>
      <option value="Pagado">Pagado</option>
      <option value="Rechazado">Rechazado</option>
    </select><br>


<?php include_once "includes/footer.php"; ?>